
-- ROOT USER
CREATE DATABASE winsol;

GRANT ALL ON winsol.* TO user_winsol@localhost IDENTIFIED BY 'pass_winsol';


-- WINSOL USER
USE winsol;

CREATE TABLE _users (
	  nick		VARCHAR(20)	NOT NULL,
	  password	VARCHAR(40)	NOT NULL,
	  mail   	VARCHAR(100)	NOT NULL,
	  name		VARCHAR(20),
	  surname	VARCHAR(60),
	  is_admin   	BOOLEAN   NOT NULL   DEFAULT false,
	  PRIMARY KEY (nick)
);

INSERT INTO _users VALUES ("admin", "pass_admin", "admin@email.com", "admin_name", "admin_surname", true);
